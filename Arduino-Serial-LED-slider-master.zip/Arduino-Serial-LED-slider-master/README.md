# Arduino-Serial-LED-slider
Python/arduino - Creates a basic interface with sliders for adjusting colours on a connected Arduino with RBG LED

Uses libraries:
pySerial
tkinter

